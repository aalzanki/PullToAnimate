//
//  ViewController.swift
//  PullToMakeAnimations
//
//  Created by Abdulrahman AlZanki on 8/17/15.
//  Copyright (c) 2015 Abdulrahman AlZanki. All rights reserved.
//

import UIKit

class CoolViewController: UITableViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupRefreshControl()
    }
    
    func setupRefreshControl() {
        refreshControl?.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
    }
    
    func refresh(sender:AnyObject) {
        NSTimer.scheduledTimerWithTimeInterval(0,
            target: refreshControl!,
            selector: Selector("endRefreshing"),
            userInfo: nil,
            repeats: false)
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
}