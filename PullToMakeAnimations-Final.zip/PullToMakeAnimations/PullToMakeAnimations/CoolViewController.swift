//
//  ViewController.swift
//  PullToMakeAnimations
//
//  Created by Abdulrahman AlZanki on 8/17/15.
//  Copyright (c) 2015 Abdulrahman AlZanki. All rights reserved.
//

import UIKit

class CoolViewController: UITableViewController {
    var makeLogo : UIImageView!
    var dolphin : UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupRefreshControl()
        
        setupMakeLogo()
        setupDolphin()
    }
    
    func setupRefreshControl() {
        refreshControl?.addTarget(self, action: "refresh:", forControlEvents: UIControlEvents.ValueChanged)
        refreshControl?.tintColor = UIColor.clearColor()
    }
    
    func setupMakeLogo() {
        makeLogo = UIImageView(image: UIImage(named: "make"))
        makeLogo.frame = CGRectMake(50, -30, 25, 25)
        self.tableView.addSubview(makeLogo)
    }
    
    func setupDolphin() {
        // The dolphin asset is from icons8.com
        let dolphinImage = UIImage(named: "dolphin")!
        dolphin = UIImageView(image: dolphinImage.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate))
        dolphin.tintColor = UIColor(red: 32 / 255, green: 122 / 255, blue: 181 / 255, alpha: 1)
        dolphin.frame = CGRectMake(50, -6, 30, 30)
        self.tableView.addSubview(dolphin)
    }
    
    func refresh(sender:AnyObject) {
        NSTimer.scheduledTimerWithTimeInterval(0,
            target: refreshControl!,
            selector: Selector("endRefreshing"),
            userInfo: nil,
            repeats: false)
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    
    override func scrollViewDidScroll(scrollView: UIScrollView) {
        let y = scrollView.contentOffset.y
        
        let spedUpY = -y * 2
        let rotationY = sin(y / 2)
        
        makeLogo.center = CGPointMake(spedUpY - 150, makeLogo.center.y)
        dolphin.center = CGPointMake(spedUpY - 158, dolphin.center.y)
        dolphin.transform = CGAffineTransformMakeRotation((rotationY / 7) - CGFloat(M_PI_4))
        makeLogo.transform = CGAffineTransformMakeRotation(-rotationY / 4)
    }
}